# Java Backend Example

Simple Spring Boot controller that returns a greeting. Used to demonstrate backend structure and API endpoint creation.