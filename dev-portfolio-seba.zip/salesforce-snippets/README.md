# Salesforce Snippets

Basic Apex trigger and test class for the Case object. Ensures subject field is auto-filled if left blank.