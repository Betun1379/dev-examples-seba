# React UI Sample

Simple filtering component made with React. Demonstrates state management and list rendering.